from django.apps import AppConfig

class NflScheduleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nfl_schedule'
